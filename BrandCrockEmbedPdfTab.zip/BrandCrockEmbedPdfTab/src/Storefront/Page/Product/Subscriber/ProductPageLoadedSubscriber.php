<?php declare(strict_types=1);

namespace Bc\BrandCrockEmbedPdfTab\Storefront\Page\Product\Subscriber;

use Shopware\Storefront\Page\Product\ProductPageLoadedEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Shopware\Core\Framework\Uuid\Uuid;
use Doctrine\DBAL\Connection;

class ProductPageLoadedSubscriber implements EventSubscriberInterface
{

    private $connection;


    public function __construct(
        Connection $connection
    )
    {
        $this->connection = $connection;
    }
    public static function getSubscribedEvents()
    {
        return [
            ProductPageLoadedEvent::class => 'onProductPageLoaded'
        ];
    }

    public function onProductPageLoaded(ProductPageLoadedEvent $event): void
    {
        //Get Custom field data
        $getProductTranslateData = $event->getPage()->getProduct()->getTranslated()['customFields'];


        $mediaId = $getProductTranslateData['custom_bc_pdf_tab'];


        $query = $this->connection->createQueryBuilder()
            ->select('m.id, m.file_name, m.file_extension')
            ->from('media m')
            ->where('m.id = :id')
            ->setParameter('id', Uuid::fromHexToBytes($mediaId));


        $queryResult = $query->execute()->fetch();



    }

}
