<?php declare(strict_types=1);

namespace Bc\BrandCrockEmbedPdfTab;

use Shopware\Core\Framework\Plugin;

use Shopware\Core\Framework\Plugin\Context\InstallContext;
use Shopware\Core\Framework\Plugin\Context\UninstallContext;
use Shopware\Core\Framework\Uuid\Uuid;
use Doctrine\DBAL\Connection;
use Shopware\Core\Defaults;

class BrandCrockEmbedPdfTab extends Plugin
{
    public function Install(InstallContext $context): void
    {
        parent::Install($context);

        $connection = $this->container->get(Connection::class);

        $customFieldSetId = Uuid::randomBytes();
        $connection->insert('custom_field_set', [
            'id' => $customFieldSetId,
            'name' => 'custom_bc_pdf',
            'config' => '{"label": {"de-DE": "PDF-Tab", "en-GB": "PDF Tab"}, "translated": true}',
            'active' => 1,
            'created_at' => (new \DateTimeImmutable())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
        ]);

        $customFieldRelationId = Uuid::randomBytes();
        $connection->insert('custom_field_set_relation', [
            'id' => $customFieldRelationId,
            'set_id' => $customFieldSetId,
            'entity_name' => 'product',
            'created_at' => (new \DateTimeImmutable())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
        ]);

        $customFieldId = Uuid::randomBytes();
        $connection->insert('custom_field', [
            'id' => $customFieldId,
            'name' => 'custom_bc_pdf_tab',
            'type' => 'media',
            'config' => '{"label": {"de-DE": "PDF hochladen", "en-GB": "Upload PDF"}, "helpText": {"en-GB": null}, "validation": "required", "placeholder": {"de-DE": "PDF hochladen", "en-GB": "Upload PDF"}, "componentName": "sw-media-field", "customFieldType": "media", "customFieldPosition": 1}',
            'active' => 1,
            'set_id' => $customFieldSetId,
            'created_at' => (new \DateTimeImmutable())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
        ]);
    }
    public function uninstall(UninstallContext $context): void
    {
        parent::uninstall($context);

        if ($context->keepUserData()) {
            return;
        }
        $connection = $this->container->get(Connection::class);
        $connection->executeQuery("DELETE FROM custom_field_set WHERE name = 'custom_bc_pdf'");



    }
}
